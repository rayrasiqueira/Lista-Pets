package com.example.listapets.model

data class Pet(

    val foto: Int,
    val nome: String,
    val descricao: String,
    val info: String

)