package com.example.listapets

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.LayoutManager
import com.example.listapets.Adapter.AdapterPet
import com.example.listapets.model.Pet

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        supportActionBar!!.hide()
        val recyclerView_pets = findViewById<RecyclerView>(R.id.recyclerView_pets)
        recyclerView_pets.layoutManager = LinearLayoutManager(this)
        recyclerView_pets.setHasFixedSize(true)
        val listaPet: MutableList<Pet> = mutableListOf()
        val adapterPet = AdapterPet(this, listaPet)
        recyclerView_pets.adapter = adapterPet

        val pet1 = Pet(
            R.drawable.teobaldo,
            "Teobaldo",
            "Gato SRD, não mia, aproximadamente 3 anos; amigável e companheiro; gosta de brincar com esponjas de maquiagem e fofocar no portão.",
            "Castrado e vacinado"
        )
        listaPet.add(pet1)

        val pet2 = Pet(
            R.drawable.potter,
            "Potter",
            "Cachorro SRD, 10 anos de idade, morde todo mundo, adora passear e brincar com bolinhas; tem medo de trovões.",
            "Vacinado"
        )
        listaPet.add(pet2)

        val pet3 = Pet(
            R.drawable.valente,
            "Valente",
            "Gato SRD, 1 ano de idade, gosta de escalar tudo e pegar insetos voadores; dorme quase o dia todo; ama sachê.",
            "Castrado e vacinado"
        )
        listaPet.add(pet3)

        val pet4 = Pet(
            R.drawable.diana,
            "Diana",
            "Cadela SRD, grande porte, 9 anos de idade; adora pular e tentar derrubar quem brinca com ela; seu brinquedo favorito é uma coxa de frango de plástico.",
            "Vacinada"
        )
        listaPet.add(pet4)

        val pet5 = Pet(
            R.drawable.bigodinha,
            "Bigodinha",
            "Gata SRD, também atende por Bibi; fica pelas ruas se aventurando e se bobear rouba comida de cima da pia da cozinha; Bibi tem 3 filhotes.",
            "Castrada e vacinada"
        )
        listaPet.add(pet5)

        val pet6 = Pet(
            R.drawable.mimi,
            "Mimi",
            "Gata SRD, aproximadamente 7 anos de idade, gosta de carinhos; exploradora do cemitério e caçadora noturna.",
            "Não vacinada"
        )
        listaPet.add(pet6)
    }
}