package com.example.listapets.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.listapets.R
import com.example.listapets.model.Pet

class AdapterPet(private val context: Context, private val pets: MutableList<Pet>): RecyclerView.Adapter<AdapterPet.PetViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PetViewHolder {
        val itemLista = LayoutInflater.from(context).inflate(R.layout.pet_item, parent, false)
        val holder = PetViewHolder(itemLista)
        return holder
    }

    override fun onBindViewHolder(holder: PetViewHolder, position: Int) {
        holder.foto.setImageResource(pets[position].foto)
        holder.nome.text = pets[position].nome
        holder.descricao.text = pets[position].descricao
        holder.info.text = pets[position].info
    }

    override fun getItemCount(): Int = pets.size

    inner class PetViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val foto = itemView.findViewById<ImageView>(R.id.fotoPet)
        val nome = itemView.findViewById<TextView>(R.id.nomePet)
        val descricao = itemView.findViewById<TextView>(R.id.descricaoPet)
        val info = itemView.findViewById<TextView>(R.id.infoPet)
    }

}